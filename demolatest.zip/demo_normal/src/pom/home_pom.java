package pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import libraries.wait_type;

public class home_pom {

	
	WebDriver dr;
	wait_type wt;
	
	
	By name=By.xpath("//div[@class='header-links']/ul/li[1]/a");
	
	public home_pom(WebDriver dr)
	{
		this.dr=dr;
	}
	
	public String read_name()
	{
		return dr.findElement(name).getText();
	}
}
