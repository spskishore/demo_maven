package pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import libraries.wait_type;



public class login_pom {

	
	WebDriver dr;
	wait_type wt;

	
	By uid=By.xpath("//input[@id='Email']");
	By pwd=By.xpath("//input[@id='Password']");
	By login=By.xpath("//input[@class='button-1 login-button']");

	
	public login_pom(WebDriver dr)
	{
		this.dr=dr;
	}
	
	public void set_uid(String un)
	{
		//WebElement we_eid=wt.waitForElement(uid, 20);
//		we_eid.sendKeys(un1);
		dr.findElement(uid).sendKeys(un);
		
		
	}
	
	public void set_pwd(String pa)
	{
//		WebElement  we_pwd=wt.waitForElement(pwd, 20);
//		we_pwd.sendKeys(pass);
		dr.findElement(pwd).sendKeys(pa);
	}
	 
	public void set_login()
	{
//		WebElement we_sub=wt.elementToBeClickable(getname, 20);
//		we_sub.click();
		dr.findElement(login).click();
	}
	
	public void do_login(String u, String p)
	{
		this.set_uid(u);
		this.set_pwd(p);
		this.set_login();
	}
	
	public String get_title()
	{
		return dr.getTitle();
	}
	
	public String get_name()
	{
		String name=dr.findElement(By.xpath("//div[@id='WelcomeContent']/div")).getText();
		return name;
		
	}
}
