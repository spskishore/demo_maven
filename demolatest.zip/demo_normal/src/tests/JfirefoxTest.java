package tests;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import excel.excel_arr;
import libraries.utilities;
import libraries.wait_type;
import pom.login_pom;
import pom.reg_pom;



public class JfirefoxTest extends excel_arr {


}
